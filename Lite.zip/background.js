/**
 * AEON HUNTER LITE - BACKGROUND CORE (V1.0.3)
 * Central Hub for Traffic Interception, Message Routing & Repeater Proxy
 * Optimized for English Standard & Chrome Security Policy
 */

// 1. Sidebar Configuration
// Sets the behavior to open the side panel when the extension icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error("[AEON LITE] SidePanel Setup Error:", error));

/**
 * 2. Traffic Interceptor
 * Monitors network requests and broadcasts data to the Dashboard.
 * Host patterns are narrowed to http/https for faster review.
 */
chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
        const requestData = {
            type: "NEW_REQUEST",
            data: {
                url: details.url,
                method: details.method,
                resourceType: details.type,
                timestamp: new Date().toLocaleTimeString()
            }
        };

        // Broadcast data to the Dashboard (must be open to receive)
        chrome.runtime.sendMessage(requestData).catch(() => {
            // Dashboard is likely closed; ignore the disconnection error
        });
    },
    { urls: ["http://*/*", "https://*/*"] }, // Updated from broad <all_urls>
    ["requestHeaders"]
);

/**
 * 3. Central Message Router
 * Handles internal communication between Content Scripts and the Dashboard.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
    // Action: Fire Proxy Request (Repeater Module)
    if (message.action === "REPEATER_FIRE") {
        executeLiteRepeater(message.payload).then(sendResponse);
        return true; // Keep channel open for async response
    }

    // Action: Basic System Health Check
    if (message.action === "GET_HEALTH") {
        sendResponse({ status: "ONLINE", version: "1.0.3-LITE" });
        return true;
    }
});

/**
 * 4. Repeater Proxy Engine
 * Executes external requests from the background context to bypass CORS limitations.
 */
async function executeLiteRepeater(payload) {
    const { url, method, headers, body } = payload;
    try {
        const startTime = performance.now();
        const response = await fetch(url, {
            method: method,
            headers: headers,
            body: method !== 'GET' ? body : undefined
        });
        
        const duration = (performance.now() - startTime).toFixed(2);
        const responseText = await response.text();

        return {
            status: "success",
            response: {
                statusCode: response.status,
                data: responseText,
                time: `${duration}ms`
            }
        };
    } catch (err) {
        return { 
            status: "error", 
            message: `[PROXY_FAIL]: ${err.message}` 
        };
    }
}

/**
 * 5. Lifecycle Initialization
 */
chrome.runtime.onInstalled.addListener(() => {
    console.log("%c[AEON LITE] CORE_ACTIVATED_V1.0.3", "color: #f85149; font-weight: bold; border: 1px solid #f85149; padding: 2px 5px;");
});