/**
 * AEON HUNTER LITE - CONTENT ENGINE (V1.0.3)
 * Features: 
 * - Context-aware communication (Prevents "Invalidated" errors)
 * - DOM Reconnaissance for potential entry points
 * - Safe payload injection for security testing
 */

(function() {
    "use strict";

    // Configuration for UI feedback
    const CONFIG = {
        TAG: "[AEON LITE]",
        COLORS: {
            PRIMARY: "#ff0033",
            BG_HIGHLIGHT: "rgba(255, 0, 51, 0.05)"
        }
    };

    console.log(`%c${CONFIG.TAG} ENGINE_INITIALIZED`, `color: ${CONFIG.COLORS.PRIMARY}; font-weight: bold; border: 1px solid ${CONFIG.COLORS.PRIMARY}; padding: 2px 5px;`);

    /**
     * Safe wrapper for chrome.runtime calls to prevent "Extension context invalidated" errors
     */
    const safeSendMessage = (message) => {
        if (chrome.runtime?.id) {
            chrome.runtime.sendMessage(message, () => {
                if (chrome.runtime.lastError) {
                    // Context invalidated or port closed; ignore silently
                }
            });
        }
    };

    /**
     * 1. RECONNAISSANCE ENGINE
     * Scrapes the DOM for inputs, data attributes, and potential sinks
     */
    function performRecon() {
        const discovery = {
            params: new Set(),
            endpoints: new Set(),
            vulnerableSinks: []
        };

        // Scrape inputs and data attributes
        const selectors = 'input, textarea, select, [name], [id], [data-id]';
        document.querySelectorAll(selectors).forEach(el => {
            if (el.name) discovery.params.add(el.name);
            if (el.id) discovery.params.add(el.id);
            Object.keys(el.dataset).forEach(key => discovery.params.add(`data-${key}`));
        });

        // Regex for endpoint discovery within the HTML
        const urlPattern = /(?:https?:\/\/|(?:\/api\/v[0-9]))[^\s'"]+/gi;
        const matches = document.documentElement.innerHTML.match(urlPattern) || [];
        matches.forEach(url => discovery.endpoints.add(url));

        // Basic Sink Detection (Looking for dangerous patterns in scripts)
        const dangerPatterns = [
            { pattern: ".innerHTML", type: "DOM_XSS" },
            { pattern: "eval(", type: "CODE_EXEC" },
            { pattern: "location.href", type: "REDIRECT_SINK" }
        ];

        document.querySelectorAll('script').forEach(script => {
            const content = script.textContent;
            dangerPatterns.forEach(item => {
                if (content.includes(item.pattern)) {
                    discovery.vulnerableSinks.push(`${item.type}: ${item.pattern}`);
                }
            });
        });

        return {
            params: Array.from(discovery.params).slice(0, 50),
            links: Array.from(discovery.endpoints).slice(0, 30),
            sinks: [...new Set(discovery.vulnerableSinks)],
            pageInfo: {
                title: document.title,
                url: window.location.href,
                timestamp: new Date().toISOString()
            }
        };
    }

    /**
     * 2. INJECTION ENGINE
     * Injects testing payloads into inputs and textareas
     */
    function executeInjection(type, custom = null) {
        const library = {
            xss: "<script>alert('AEON_HUNT')</script>",
            sqli: "' OR '1'='1' --",
            lfi: "../../../../etc/passwd"
        };

        const payload = custom || library[type] || library.xss;
        const targets = document.querySelectorAll('input:not([type="hidden"]), textarea, [contenteditable="true"]');
        
        let count = 0;
        targets.forEach(input => {
            try {
                if (input.hasAttribute('contenteditable')) {
                    input.innerText = payload;
                } else {
                    input.value = payload;
                }

                // Styling for visual feedback of target identification
                input.style.border = `1px solid ${CONFIG.COLORS.PRIMARY}`;
                input.style.backgroundColor = CONFIG.COLORS.BG_HIGHLIGHT;

                // Trigger events so modern frameworks (React/Vue) detect the change
                ['input', 'change', 'blur'].forEach(ev => input.dispatchEvent(new Event(ev, { bubbles: true })));
                count++;
            } catch (e) { /* Ignore DOM isolation errors */ }
        });

        return { status: "SUCCESS", count, payload };
    }

    /**
     * 3. MESSAGE LISTENER
     */
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "GET_RECON_DATA") {
            sendResponse(performRecon());
        } else if (request.action === "AUTO_INJECT") {
            sendResponse(executeInjection(request.payloadType, request.customPayload));
        }
        return true; 
    });

    /**
     * 4. SPA MONITOR
     * Detects URL changes in Single Page Applications (React/Vue/Angular)
     */
    let lastUrl = location.href;
    const observer = new MutationObserver(() => {
        const currentUrl = location.href;
        if (currentUrl !== lastUrl) {
            lastUrl = currentUrl;
            
            if (chrome.runtime?.id) {
                safeSendMessage({ 
                    type: "SPA_NAVIGATED", 
                    url: lastUrl 
                });
            } else {
                observer.disconnect(); // Stop observing if extension is reloaded/removed
            }
        }
    });

    observer.observe(document, { subtree: true, childList: true });

})();